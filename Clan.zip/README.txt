To run Themler open this url in your browser:
http://host/themes/[theme_name]/__editor__/app.html

We strongly recommend to password protect http://host/themes/[theme_name]/__editor__/app.html folder to prevent unauthorized access to the content by a third party.